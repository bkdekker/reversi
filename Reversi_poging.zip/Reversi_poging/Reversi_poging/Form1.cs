﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Reversi_poging
{
   /* class toestand
        {
        public int red_;
        public int blue_;
        public int wit_rondje_;
        public toestand(int r, int b, int w)
        {
            this.red_ = r;
            this.blue_ = b;
            this.wit_rondje_ = w;
        }
        

    }*/
    public partial class Form1 : Form
    {
        int[,] boord;
        int grootte;
       // private toestand toestand_R;
        int red;
        int blue;
        int wit_bol;
        int niks;
        public Form1()
        {
            //red = toestand
            red = 1;
            blue = 2;
            wit_bol = 3;
            niks = 0;
            //toestand_R = new toestand();
            //toestand_R.
            InitializeComponent();
            grootte = 6;
            boord = new int[grootte, grootte];
            for (int i = 0; i < grootte; i++)
            {

                for (int j = 0; j < grootte; j++)
                {
                    if ((i == 2 && j == 2) || (i == 3 && j ==3))
                    {
                        boord[i, j] = red;
                    }
                    else if ((i == 2 && j == 3) || (i == 3 && j == 2))
                    {
                        boord[i, j] = blue;
                    }
                    else
                    {
                        boord[i, j] = niks;
                    }
                }
            }


        }
        private void panel3_Paint(object sender, PaintEventArgs pea)
        {
            Graphics gr = pea.Graphics;
            int stap1 = (panel3.Width-1) / grootte;
            int stap2 = (panel3.Height - 1) / grootte;
            for (int i = 0; i < grootte; i++)
            {
                
                for (int j = 0; j < grootte; j++)
                {
                    gr.DrawRectangle(Pens.Black, i * stap1, j * stap2, stap1, stap2);
                    if (boord[i,j] == red)
                    {
                        gr.FillEllipse(Brushes.Red, i * stap1, j * stap2, stap1, stap2);
                    }
                    else if (boord[i,j] == blue)
                    {
                        gr.FillEllipse(Brushes.Blue, i * stap1, j * stap2, stap1, stap2);
                    }

                }
            }
        }
        private void panel2_Paint(object sender, PaintEventArgs pea)
        {
            Graphics gr = pea.Graphics;
            gr.FillEllipse(Brushes.Blue, 0, 0, panel2.Width - 1, panel2.Height - 1);
        }

        private void panel1_Paint(object sender, PaintEventArgs pea)
        {
            Graphics gr = pea.Graphics;
            gr.FillEllipse(Brushes.Red, 0, 0, panel2.Width - 1, panel2.Height - 1);
        }



        private void nieuw_spel_Click(object sender, EventArgs e)
        {

        }

        private void help_Click(object sender, EventArgs e)
        {

        }


    }
}
