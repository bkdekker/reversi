﻿namespace Reversi_poging
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nieuw_spel = new System.Windows.Forms.Button();
            this.help = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.aan_zet = new System.Windows.Forms.Label();
            this.rood_aantal = new System.Windows.Forms.Label();
            this.blauw_aantal = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // nieuw_spel
            // 
            this.nieuw_spel.Location = new System.Drawing.Point(173, 12);
            this.nieuw_spel.Name = "nieuw_spel";
            this.nieuw_spel.Size = new System.Drawing.Size(96, 39);
            this.nieuw_spel.TabIndex = 0;
            this.nieuw_spel.Text = "nieuw spel";
            this.nieuw_spel.UseVisualStyleBackColor = true;
            this.nieuw_spel.Click += new System.EventHandler(this.nieuw_spel_Click);
            // 
            // help
            // 
            this.help.Location = new System.Drawing.Point(275, 12);
            this.help.Name = "help";
            this.help.Size = new System.Drawing.Size(74, 39);
            this.help.TabIndex = 1;
            this.help.Text = "help";
            this.help.UseVisualStyleBackColor = true;
            this.help.Click += new System.EventHandler(this.help_Click);
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(84, 78);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(61, 61);
            this.panel1.TabIndex = 2;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // panel2
            // 
            this.panel2.Location = new System.Drawing.Point(84, 145);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(61, 61);
            this.panel2.TabIndex = 3;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // panel3
            // 
            this.panel3.Location = new System.Drawing.Point(84, 254);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(361, 361);
            this.panel3.TabIndex = 4;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // aan_zet
            // 
            this.aan_zet.AutoSize = true;
            this.aan_zet.Location = new System.Drawing.Point(84, 211);
            this.aan_zet.Name = "aan_zet";
            this.aan_zet.Size = new System.Drawing.Size(98, 20);
            this.aan_zet.TabIndex = 5;
            this.aan_zet.Text = "rood aan zet";
            // 
            // rood_aantal
            // 
            this.rood_aantal.AutoSize = true;
            this.rood_aantal.Location = new System.Drawing.Point(169, 88);
            this.rood_aantal.Name = "rood_aantal";
            this.rood_aantal.Size = new System.Drawing.Size(71, 20);
            this.rood_aantal.TabIndex = 7;
            this.rood_aantal.Text = "2 stenen";
            // 
            // blauw_aantal
            // 
            this.blauw_aantal.AutoSize = true;
            this.blauw_aantal.Location = new System.Drawing.Point(169, 154);
            this.blauw_aantal.Name = "blauw_aantal";
            this.blauw_aantal.Size = new System.Drawing.Size(71, 20);
            this.blauw_aantal.TabIndex = 8;
            this.blauw_aantal.Text = "2 stenen";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(578, 679);
            this.Controls.Add(this.blauw_aantal);
            this.Controls.Add(this.rood_aantal);
            this.Controls.Add(this.aan_zet);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.help);
            this.Controls.Add(this.nieuw_spel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button nieuw_spel;
        private System.Windows.Forms.Button help;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label aan_zet;
        private System.Windows.Forms.Label rood_aantal;
        private System.Windows.Forms.Label blauw_aantal;
    }
}

